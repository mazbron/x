<?php
$urls = array(
"http://www.google.com/search?q=html5+games",
"http://www.google.com/search?q=arcade+games+list",
"http://www.google.com/search?q=action+game+arcade+games",
"http://www.google.com/search?q=arcade+games+free+download",
"http://www.google.com/search?q=arcade+games+unblocked",
"http://www.google.com/search?q=arcade+games+meaning",
"http://www.google.com/search?q=arcade+games+for+sale",
"http://www.google.com/search?q=best+arcade+games",
"http://www.google.com/search?q=arcade+games+near+me",
"http://www.google.com/search?q=arcade+games+unblocked",
"http://www.google.com/search?q=arcade+games+free+download",
"http://www.google.com/search?q=arcade+games+list",
"http://www.google.com/search?q=80s+arcade+games+online",
"http://www.google.com/search?q=online+games",
"http://www.google.com/search?q=free+online+games",
"http://www.google.com/search?q=action+game+arcade+games",
"http://www.google.com/search?q=crazy+games",
);
$url = $urls[array_rand($urls)];
header("Location: $url");
?>
