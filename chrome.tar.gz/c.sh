#!/bin/bash
stty -echo
COUNTER=0
while :
do
chromium-browser --disable-session--crashed-bubble & sleep 1 & chromium-browser --disable-session--crashed-bubble & sleep 1000
echo Chromium Browser has been restarted $COUNTER times
let COUNTER=COUNTER+1
killall chromium-browser
killall chromium-browser
sleep 5
done
