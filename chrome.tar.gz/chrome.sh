#!/bin/bash
COUNTER=0
while :
do
killall chrome
/usr/bin/google-chrome-stable --disable-session--crashed-bubble --incognito --app-id=idlecgefglkakajapdiiifbcoccpehco & sleep 2 & /usr/bin/google-chrome-stable --disable-session--crashed-bubble --incognito --app-id=idlecgefglkakajapdiiifbcoccpehco & sleep 2 & /usr/bin/google-chrome-stable --disable-session--crashed-bubble --incognito --app-id=idlecgefglkakajapdiiifbcoccpehco & sleep 2 & /usr/bin/google-chrome-stable --disable-session--crashed-bubble --incognito --app-id=idlecgefglkakajapdiiifbcoccpehco & sleep 2 & /usr/bin/google-chrome-stable --disable-session--crashed-bubble --incognito --app-id=idlecgefglkakajapdiiifbcoccpehco & sleep 1000
echo Google Chrome has been restarted $COUNTER times
let COUNTER=COUNTER+1
killall chrome
killall chrome
sleep 5
done
